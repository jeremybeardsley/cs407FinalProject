
package cs407final;


public class CS407Final {


    public static void main(String[] args) throws InvalidArgumentException {
       Animal yogi = AnimalFactory.createAnimal('b');
       Animal gnu = AnimalFactory.createAnimal('a');
    }
    
}
